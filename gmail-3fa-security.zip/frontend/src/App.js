
// Frontend: Main App Component
import React from 'react';

function App() {
    return (
        <div>
            <h1>You are secure!</h1>
        </div>
    );
}

export default App;
