
// Backend: Node.js with Express (Error Handling Fixed)
const express = require('express');
const { google } = require('googleapis');
const dotenv = require('dotenv');
dotenv.config();
const cors = require('cors');
const multer = require('multer');
const fs = require('fs').promises;
const path = require('path');
const vision = require('@google-cloud/vision');
const crypto = require('crypto');
const visionClient = new vision.ImageAnnotatorClient();

const app = express();
app.use(express.json());
app.use(cors());

const oauth2Client = new google.auth.OAuth2(
    process.env.CLIENT_ID,
    process.env.CLIENT_SECRET,
    process.env.REDIRECT_URI
);

// Improved Google Authentication with Error Handling
app.get('/auth/google', async (req, res) => {
    try {
        const authUrl = oauth2Client.generateAuthUrl({
            access_type: 'offline',
            scope: ['https://www.googleapis.com/auth/gmail.readonly'],
        });
        res.redirect(authUrl);
    } catch (error) {
        res.status(500).json({ success: false, message: "Google Auth failed", error: error.message });
    }
});

// Improved Retina Scan Verification with Error Handling
const upload = multer({ dest: 'uploads/' });
app.post('/verify-retina', upload.single('image'), async (req, res) => {
    try {
        const { email } = req.body;
        const imagePath = req.file.path;

        if (!email) return res.status(400).json({ success: false, message: "Email is required" });

        const [result] = await visionClient.faceDetection(imagePath);
        await fs.unlink(imagePath); // Non-blocking deletion

        if (!result || !result.faceAnnotations.length) {
            return res.status(400).json({ success: false, message: "No valid face detected" });
        }

        const face = result.faceAnnotations[0];
        if (face.detectionConfidence < 0.85) {
            return res.status(400).json({ success: false, message: "Low confidence in retina scan" });
        }

        res.json({ success: true, message: "Retina scan successful!" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error processing retina scan", error: error.message });
    }
});

// Deploy the server with improved static file handling
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
