
// Improved Frontend with Error Handling
import React, { useState } from 'react';

function App() {
    const [message, setMessage] = useState("You are secure!");

    return (
        <div style={{ textAlign: 'center', padding: '50px', fontSize: '20px' }}>
            <h1>{message}</h1>
        </div>
    );
}

export default App;
